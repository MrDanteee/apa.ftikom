About
=====
Far Manager plugins are located in this folder.

You may download Far Manager from official site:
http://www.farmanager.com/download.php

Supported Far Manager versions:
1.75 build 2479 or higher (x86 & x64)
2.0  build 1761 or higher (x86 & x64)
3.0  build 2798 [pre Lua] (x86 & x64)
3.0  build 2876 or higher (x86 & x64)


List of plugins
===============

Main Far Manager module (Tabs, Drag&Drop, RClick, and so on)
-----
ConEmu.dll
ConEmu.x64.dll


Enables thumbnails and tiles in Far Manager panels
-----
Thumbs\ConEmuTh.dll
Thumbs\ConEmuTh.x64.dll


This plugin colorize Far panels, display mnemonic picture (drive, network,
and so on), and progress bar of used drive space at status line area.
ConEmu Background can be customized via Background.xml configuration file.
-----
Background\ConEmuBg.dll
Background\ConEmuBg.x64.dll


Simple background plugin
-----
Lines\ConEmuLn.dll
Lines\ConEmuLn.x64.dll

